const Gameboard = [];

function player(name, char) {
  return {
    name,
    character: char,
    draw: function (element) {
      if (element.textContent === "") {
        element.textContent = this.character;
      }
    },
  };
}

const player1 = player("playerX", "X");
const player2 = player("playerO", "O");

const gameLogic = {
  playing: true,
  drawingBlocks: document.querySelectorAll(".block"),
  currentPlayer: player1,
};

// console.log(gameLogic.currentplayer);

gameLogic.drawingBlocks.forEach((block) => {
  block.addEventListener("click", () => {
    gameLogic.currentPlayer.draw(block);
    console.log(block);
  });
});

Gameboard.push(player1, player2);

// console.log(gameLogic.drawingBlocks);
